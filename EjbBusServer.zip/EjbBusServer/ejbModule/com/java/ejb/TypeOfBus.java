package com.java.ejb;

public enum TypeOfBus {
     
	AC,SLEEPER,SEATER,NON_AC
}
