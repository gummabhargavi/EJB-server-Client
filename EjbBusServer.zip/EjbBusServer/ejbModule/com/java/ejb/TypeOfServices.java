package com.java.ejb;

public enum TypeOfServices {
	
	REGULAR,WEEKEND,ALTERNATE_DAYS,EVENT

}
